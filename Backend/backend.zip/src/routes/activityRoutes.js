// src/routes/activityRoutes.js
const express = require('express');
const router = express.Router();
const { generateAndSaveActivity, getActivitiesForChild } = require('../controllers/activityController');

router.post('/generate', generateAndSaveActivity);
router.get('/child/:childId', getActivitiesForChild);

module.exports = router;