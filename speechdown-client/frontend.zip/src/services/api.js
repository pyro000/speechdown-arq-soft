// src/services/api.js
import axios from 'axios';

// Creamos una instancia de Axios con la URL base de nuestro backend.
// Esto nos ahorra tener que escribirla en cada petición.
const apiClient = axios.create({
  baseURL: 'http://localhost:5000/api', // La URL de tu backend
  headers: {
    'Content-Type': 'application/json',
  },
});

// Función para registrar un usuario
export const registerUser = (userData) => {
  return apiClient.post('/users/register', userData);
};

// Función para iniciar sesión
export const loginUser = (credentials) => {
  return apiClient.post('/users/login', credentials); // Necesitarás crear esta ruta en el backend
};

// Aquí añadiremos más funciones (para niños, actividades, etc.)
// export const getChildren = (userId) => apiClient.get(`/children/user/${userId}`);