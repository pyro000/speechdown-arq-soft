// src/App.jsx
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardLayout from './pages/DashboardLayout';
import DashboardHomePage from './pages/dashboard/DashboardHomePage';
import ManageChildrenPage from './pages/dashboard/ManageChildrenPage';
import ActivityGeneratorPage from './pages/dashboard/ActivityGeneratorPage';

const router = createBrowserRouter([
  {
    path: '/',
    element: <HomePage />,
  },
  {
    path: '/login',
    element: <LoginPage />,
  },
  {
    path: '/register',
    element: <RegisterPage />,
  },
  {
    path: '/dashboard',
    element: <DashboardLayout />,
    // Rutas anidadas que se mostrarán dentro de DashboardLayout
    children: [
      {
        index: true, // La ruta por defecto /dashboard
        element: <DashboardHomePage />,
      },
      {
        path: 'children', // Se accederá como /dashboard/children
        element: <ManageChildrenPage />,
      },
      {
        path: 'generate', // Se accederá como /dashboard/generate
        element: <ActivityGeneratorPage />,
      }
    ]
  }
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;