// src/pages/dashboard/ActivityGeneratorPage.jsx
const ActivityGeneratorPage = () => {
    // Estados para el formulario
    // Estado para guardar el resultado de la IA
    // Estado para la carga (loading)

    const handleGenerate = (e) => {
        e.preventDefault();
        // 1. Poner el estado de carga en true
        // 2. Llamar a la API del backend con los datos del form
        // 3. Guardar el resultado en el estado
        // 4. Poner el estado de carga en false
    };

    return (
        <div>
            <h1 className="text-3xl font-bold mb-6">Generador de Actividades con IA</h1>
            <form onSubmit={handleGenerate} className="bg-white p-6 rounded-lg shadow">
                {/* Selector para el niño, input para el tema, input para el fonema */}
                <button type="submit" className="bg-purple-600 text-white px-6 py-2 rounded font-semibold">Generar</button>
            </form>

            {/* Aquí se mostrará el resultado */}
            <div className="mt-8 bg-white p-6 rounded-lg shadow">
                <h2 className="font-bold mb-2">Resultado:</h2>
                {/* Si está cargando, mostrar un spinner. Si hay resultado, mostrar el texto */}
                <p>El cuento generado por la IA aparecerá aquí...</p>
            </div>
        </div>
    );
};

export default ActivityGeneratorPage;